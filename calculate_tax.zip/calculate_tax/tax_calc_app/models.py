from django.db import models

# Create your models here.
class Tax_calc_user(models.Model):
  first_name = models.CharField(max_length=255)
  last_name = models.CharField(max_length=255)
  username = models.CharField(max_length=255)
  password = models.CharField(max_length=255)
  email = models.EmailField()
  def __str__(self):
      return self.first_name
  
class User_input(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    filingStatus = models.IntegerField()
    annual_income = models.FloatField(default = 0)
    tax_amount = models.FloatField(default = 0)
    username = models.CharField(null=True )
    password = models.CharField(null=True )
    def __str__(self):
      return self.first_name
    