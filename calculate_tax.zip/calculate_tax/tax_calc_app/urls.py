
from django.urls import path
from . import views

urlpatterns = [
    path('taxcalculator/', views.taxcalcapp, name='taxcalcapp'),
    path('taxcalculator/login', views.login, name='login'),
    #path('taxcalculator/backtotaxcalcapp', views.backtotaxcalcapp, name='backtotaxcalcapp')
    path('taxcalculator/register', views.register, name='register' ),
    path('taxcalculator/register_on_db', views.register_on_db, name='register_on_db'),
    path('taxcalculator/logging', views.logging, name='logging'),
    path('taxcalculator/tax_data_input_form', views.tax_data_input_form, name='tax_data_input_form'),
    path('taxcalculator/enter_into_database', views.enter_into_database, name='enter_into_database'),
    path('taxcalculator/showtaxdata', views.showtaxdata, name='showtaxdata'),
    path('taxcalculator/logout', views.logout, name='logout'),
]
