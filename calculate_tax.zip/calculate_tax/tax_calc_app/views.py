from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.models import User, auth
from django .contrib import messages
from .models import User_input

# Create your views here.
def taxcalcapp(request):
    return render(request, 'taxcalcapp.html')

def login(request):
    return render(request, 'login.html')

def register(request):
    return render(request, 'register.html')

def register_on_db(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        password = request.POST['password']
        password2 = request.POST['password2']
        email = request.POST['email']
        
        if  password == password2:
            if User.objects.filter(username=username).exists():
                #messages.add_message(request, messages.INFO, "username taken. Please use another username")
                messages.info(request, 'Username taken')
                return redirect('register')
            
            elif User.objects.filter(email=email).exists():
                messages.add_message(request, messages.INFO, "email taken. Please use another email")
                return redirect('register')
            else:   
                user = User.objects.create_user(first_name=first_name, last_name=last_name, username=username, password=password, email=email)
                user.save();
                return redirect('taxcalcapp')
                 
        else:
            messages.add_message(request, messages.INFO, "password does not much")
            return redirect('register')
    
    else:
        return render(request, 'register.html') 
    
def logging(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)

            messages.info(request, f'Now you are loggedin as {user} ' )
            userdata = User_input.objects.filter(username=username, password=password).values() # added to show data of the user.
 
            return render(request, 'loggedin.html',{'userdata':userdata})
        else:
            messages.error(request, 'Invalid credentials')
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')


def tax_data_input_form(request):
    return render(request, 'tax_data_input_form.html')

def enter_into_database(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        address = request.POST['address']
        filingStatus = request.POST['filingStatus']
        annual_income = float(request.POST['anual_income'])
        tax_amount = annual_income * 0.10
        
        user_input = User_input(first_name=first_name, last_name=last_name, address=address, filingStatus=filingStatus, annual_income=annual_income, tax_amount=tax_amount)
        user_input.save();
        return redirect('tax_data_input_form')
    
    else:
        return redirect('tax_data_input_form')

def showtaxdata(request):
    user_data = User_input.objects.all()
    return render(request, 'showtaxdata.html', {'mydata':user_data})

def logout(request):
    auth.logout(request)
    return redirect('taxcalcapp')